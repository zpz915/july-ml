import tornado.ioloop
import tornado.web
import json
import joblib

from lightgbm import LGBMClassifier
import lightgbm as lgb

import numpy as np

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Hello, world")
        
    def post(self):
        data = self.request.body.decode('utf-8')
        data = json.loads(data)
        
        data = np.array(data['data']).reshape(-1, 4)
        predict_lbl = clf.predict(data).astype(int)
        
        msg = {
            'label' : list(predict_lbl),
            'code' : 200,
        }
        self.write(json.dumps(msg))

application = tornado.web.Application([
    (r"/", MainHandler),
])


if __name__ == "__main__":
    clf = joblib.load('lgb.pkl')
    
    application.listen(9999)
    tornado.ioloop.IOLoop.instance().start()