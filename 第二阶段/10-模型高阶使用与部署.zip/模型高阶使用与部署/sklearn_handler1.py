import tornado.ioloop
import tornado.web
import json
import joblib

import numpy as np

# tornado、flask、fastapi
class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Hello 七月在线")
        
    def post(self):
        data = self.request.body.decode('utf-8')
        data = json.loads(data)
        
        data = np.array(data['data']).reshape(1, 4)
        predict_lbl = clf.predict(data)[0]
        
        msg = {
            'label' : int(predict_lbl),
            'code' : 200,
            'msg': ''
        }
        self.write(json.dumps(msg))

application = tornado.web.Application([
    (r"/", MainHandler),
])

# 地址：http://ip:端口/路径
# http://192.168.12.100:9999/

if __name__ == "__main__":
    clf = joblib.load('data1.pkl')
    
    application.listen(9999)
    tornado.ioloop.IOLoop.instance().start()