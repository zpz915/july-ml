import gc
import time
import numpy as np
import pandas as pd

from scipy.sparse import csr_matrix, hstack

from sklearn.linear_model import Ridge
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.preprocessing import LabelBinarizer
from sklearn.model_selection import train_test_split, cross_val_score
import lightgbm as lgb

NUM_BRANDS = 4004
NUM_CATEGORIES = 1001
NAME_MIN_DF = 10
MAX_FEATURES_ITEM_DESCRIPTION = 3


# 进行缺失值填充
def handle_missing_inplace(dataset):
    dataset['category_name'].fillna(value='missing', inplace=True)
    dataset['brand_name'].fillna(value='missing', inplace=True)
    dataset['item_description'].fillna(value='missing', inplace=True)

# 对类别个数进行截断
def cutting(dataset):
    pop_brand = dataset['brand_name'].value_counts().loc[lambda x: x.index != 'missing'].index[:NUM_BRANDS]
    dataset.loc[~dataset['brand_name'].isin(pop_brand), 'brand_name'] = 'missing'
    pop_category = dataset['category_name'].value_counts().loc[lambda x: x.index != 'missing'].index[:NUM_BRANDS]
    dataset.loc[~dataset['category_name'].isin(pop_category), 'category_name'] = 'missing'

# 进行字段类型转换
def to_categorical(dataset):
    dataset['category_name'] = dataset['category_name'].astype('category')
    dataset['brand_name'] = dataset['brand_name'].astype('category')
    dataset['item_condition_id'] = dataset['item_condition_id'].astype('category')


def main():
    start_time = time.time()
    
    # 读取数据
    train = pd.read_table('./train.tsv', engine='c')
    test = pd.read_table('./test.tsv', engine='c')
    
    nrow_train = train.shape[0]
    
    # 对价格进行转换，目标是获得更加均衡的数据分布
    # tips： 如果价格是标签，或回归问题的标签是非正态分布，一般需要取log等变换
    y = np.log1p(train["price"])
    
    merge = pd.concat([train, test])
    submission = test[['test_id']]

    # 手动删除变量，节约内存
    del train
    del test
    gc.collect()

    # 缺失值填充
    handle_missing_inplace(merge)

    # 字符取值裁剪
    cutting(merge)

    # 类别转换
    to_categorical(merge)

    # 对 name 商品名称字段计算字符统计
    cv = CountVectorizer(min_df=NAME_MIN_DF)
    X_name = cv.fit_transform(merge['name'])

    # 对 category_name 商品类别进行统计
    cv = CountVectorizer()
    X_category = cv.fit_transform(merge['category_name'])

    # 对 item_description 商品描述计算tfidf
    # 为什么此字段需要计算tfidf，而不是直接字符统计？
    tv = TfidfVectorizer(max_features=MAX_FEATURES_ITEM_DESCRIPTION,
                         ngram_range=(1, 3),
                         stop_words='english')
    X_description = tv.fit_transform(merge['item_description'])
    
    # http://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.LabelBinarizer.html
    # 具体实现与onehot类似，不过只支持单列转换
    lb = LabelBinarizer(sparse_output=True)
    X_brand = lb.fit_transform(merge['brand_name'])

    # 构建稀疏矩阵，稀疏数据转换后对内存友好
    # https://blog.csdn.net/chao2016/article/details/80344828
    X_dummies = csr_matrix(pd.get_dummies(merge[['item_condition_id', 'shipping']],
                                          sparse=True).values)
    
    sparse_merge = hstack((X_dummies, X_description, X_brand, X_category, X_name)).tocsr()
    X = sparse_merge[:nrow_train]
    X_test = sparse_merge[nrow_train:]
    
    d_train = lgb.Dataset(X, label=y)
    params = {
        'learning_rate': 0.75,
        'application': 'regression',
        'max_depth': 3,
        'num_leaves': 100,
        'verbosity': -1,
        'metric': 'RMSE',
    }

    # LightGBM模型
    model = lgb.train(params, train_set=d_train, num_boost_round=3200, verbose_eval=100) 
    preds = 0.57*model.predict(X_test)

    # https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.Ridge.html
    # Linear least squares with l2 regularization.
    # ‘sag’ uses a Stochastic Average Gradient descent
    # https://scikit-learn.org/stable/modules/sgd.html
    model = Ridge(solver="sag", fit_intercept=True, random_state=205)
    model.fit(X, y)
    
    preds += 0.43*model.predict(X=X_test)
    submission['price'] = np.expm1(preds)
    submission.to_csv("submission_lgbm_ridge_5.csv", index=False)

if __name__ == '__main__':
    main()