#! /bin/bash

# 20170308
rm ./*.pyc
