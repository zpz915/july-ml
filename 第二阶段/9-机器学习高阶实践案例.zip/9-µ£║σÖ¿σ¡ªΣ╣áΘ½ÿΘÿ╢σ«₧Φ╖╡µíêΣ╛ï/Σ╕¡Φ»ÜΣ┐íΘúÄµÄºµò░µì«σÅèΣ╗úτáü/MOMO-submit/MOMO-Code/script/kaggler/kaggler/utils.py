# -*- coding: utf-8 -*-
from __future__ import print_function

import numpy as np
import pandas as pd
import cPickle as pickle

def col_countsrank(df, col, percents):
    col_valuecounts = df[col].value_counts()
    for percent in percents:
        df[col + '_top{0}'.format(percent)] = df[col].apply(lambda x: 1 if x in col_valuecounts.index.values[
                col_valuecounts.values >= np.percentile(col_valuecounts.values, 100 - 1)] else 0)
                
def col_valuerank(df, col, percents = []):
    df[col + '_rank'] = df[col].rank(ascending = False)
    for percent in percents:
        df[col + '_ranktop{0}'.format(100 - percent)] = df[col + '_rank'].apply(lambda x: 1 if x > len(df) * (percent / 100.0) else 0)
        
def save_pickle(filename, data):
    with open(filename, 'w') as f:
        pickle.dump(data, f)

def load_pickle(filename):
    with open(filename) as f:
        return pickle.load(f)

# From Keras
def to_categorical(y, nb_classes=None):
    """Converts a class vector (integers) to binary class matrix.
    E.g. for use with categorical_crossentropy.
    # Arguments
        y: class vector to be converted into a matrix
            (integers from 0 to nb_classes).
        nb_classes: total number of classes.
    # Returns
        A binary matrix representation of the input.
    """
    y = np.array(y, dtype='int').ravel()
    if not nb_classes:
        nb_classes = np.max(y) + 1
    n = y.shape[0]
    categorical = np.zeros((n, nb_classes))
    categorical[np.arange(n), y] = 1
    return categorical

# 将结果csv进行加权
#   dfs，dataframe list
#   scale，加权权重
#   id_col，ID列名
def result_blend(dfs, scale, id_col):
    file_col = dfs[0].columns
    submit_col = dfs[0].drop(id_col, axis = 1).columns
    for i, df in enumerate(dfs):
        new_colnames = {}
        for col in submit_col:
            new_colnames[col] = col + str(i)
        dfs[i].rename(columns = new_colnames, inplace = True)
        
    df_merge = pd.DataFrame()
    for i, df in enumerate(dfs):
        if i == 0:
            df_merge = df
        else:
            df_merge = pd.merge(df_merge, df, left_on = 'listing_id', right_on = 'listing_id')
            
    for col in submit_col:
        for i, df in enumerate(dfs):
            if i == 0:
                df_merge[col] = df_merge[col + str(i)] * scale[i]
            else:
                df_merge[col] += df_merge[col + str(i)] * scale[i]
    return df_merge[file_col]