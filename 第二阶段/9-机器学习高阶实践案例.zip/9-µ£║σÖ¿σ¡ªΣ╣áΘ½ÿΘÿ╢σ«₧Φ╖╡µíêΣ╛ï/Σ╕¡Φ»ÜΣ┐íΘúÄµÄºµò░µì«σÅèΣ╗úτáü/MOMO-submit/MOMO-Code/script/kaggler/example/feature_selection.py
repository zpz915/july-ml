# -*- coding: utf-8 -*-
from __future__ import print_function


import sys
sys.path.insert(0, "/home/lyz/Workspace/Kaggle/kaggler")
from kaggler.feature_selection import *
from sklearn.feature_selection import *

from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.datasets import load_iris
iris = load_iris()

print('FilterSelection testing...')
print(FilterSelection().fit(iris.data, iris.target, f_classif))
print(FilterSelection().select_best(iris.data, iris.target, SelectKBest(f_classif, k = 2)))

print('WrapperSelection testing...')
print(WrapperSelection(LogisticRegression()).fit(iris.data, iris.target, 2))
print(WrapperSelection(LogisticRegression()).fitcv(iris.data, iris.target, accuracy_score))

print('EmbeddedSelection testing...')
print(EmbeddedSelection(LogisticRegression(penalty="l1", C=0.1)).fit(iris.data, iris.target))
print(EmbeddedSelection(GradientBoostingClassifier()).fit(iris.data, iris.target))
