# -*- coding: utf-8 -*-
from __future__ import print_function

__author__ = "Liu"
__copyright__ = "Copyright 2017, China Chengxin Credit Modeling Competition"

import pandas as pd
import numpy as np
import sys, os, re, codecs

np.random.seed(235)
sys.path.append('./kaggler/')
from kaggler.model_wrapper import *
import xgboost as xgb

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score

def read_input(path = '../input/'):
    train_set = pd.read_csv(path + 'train.csv', encoding = 'gbk')
    test_set = pd.read_csv(path + 'test.csv', encoding = 'gbk')
    train_test = pd.concat([train_set.drop(['target'], axis = 1), test_set], axis = 0, ignore_index = True)
    train_test.drop(['id'], axis = 1, inplace = True)
    return train_set, test_set, train_test

def preprocess(train_test):
    ############################################################################
    # 数据清洗：特征剔除，样本剔除
    ############################################################################
    def del_col(df, cols):
        for col in cols:
            if col in df.columns:
                df = df.drop(col, axis = 1)
        return df

    # 特征：剔除缺失比例大于0.97的
    df_nan = pd.DataFrame(train_test.isnull().sum(axis = 0) * 1.0 / train_test.shape[0], columns =['nan'])
    train_test = del_col(train_test, df_nan[df_nan['nan'] > 0.97].index)
    print('Drop nan', train_test.shape)

    # 特征：剔除方差太小的
    df_std = pd.DataFrame(train_set.std(axis = 0), columns= ['std'])
    train_test = del_col(train_test, df_std[df_std['std'] < 0.05].index)
    print('Drop std', train_test.shape)

    # 特征：剔除二分类，且分布不一致的
    df_ncount = []
    for col in train_test.columns:
        df_ncount.append([col, train_test[col].nunique(), train_set[col].nunique(), test_set[col].nunique()])
    df_ncount = pd.DataFrame(df_ncount, columns= ['var', 'all', 'train', 'test'])
    df_ncount_drop = df_ncount.loc[(df_ncount['train'] != df_ncount['test']) & (df_ncount['train'] <= 2)].iloc[:]
    train_test = del_col(train_test, df_ncount_drop['var'])
    print('Drop dis', train_test.shape)

    # 样本：剔除离群样本
    # TODO

    ############################################################################
    # 类别编码
    ############################################################################
    # var19 职业信息
    print('Encoding var19')
    train_test.loc[train_test['var19'].apply(lambda x: x in [u'公务员',u'军人']), 'var19'] = u'国企事业单位职工'
    train_test.loc[train_test['var19'].apply(lambda x: x in [u'家庭主妇', u'失业人员']), 'var19'] = u'自由职业者'
    train_test.loc[train_test['var19'].apply(lambda x: x in [u'家庭主妇', u'失业人员']), 'var19'] = u'自由职业者'

    train_test.loc[train_test['var19'].apply(lambda x:
            x not in [u'公司受雇员工', u'私企公司职工', u'国企事业单位职工',
                      u'自雇创业人员', u'自主创业人员', u'自由职业者', u'农林牧副渔人员']), 'var19'] = u'私企公司职工'
    train_test['var19'] = pd.factorize(train_test['var19'])[0]
    train_test['var19'] = train_test['var19'].astype(int)

    # NaN编码
    # TODO

    print('ALL DATA', train_test.shape)
    return train_test

# 城市经纬度
def city_latiude(train_test):
    city_txt = codecs.open('./city_map.txt').readlines()
    print('Encoding city')
    city_map = {}
    for line in city_txt:
        if ':' not in line or ';' not in line:
            continue
        line = line[:-2]
        line_split = re.split(' |:', line)
        city_map[line_split[1]] = [float(line_split[3]), float(line_split[5])]

    city_latiude_df = []
    for city in train_test['var21']:
        city = city[:-1]

        flag = 0
        citys = city_map.keys()
        for city_a in citys:
            if city in city_a.decode('utf-8'):
                city_latiude_df.append(city_map[city_a])
                flag = 1
                break
        if flag == 0:
            city_latiude_df.append([-1, -1])
    city_latiude_df = pd.DataFrame(city_latiude_df, columns=['var21_cityx', 'var21_cityy'])
    return  city_latiude_df

def feature(train_test):
    def del_col(df, cols):
        for col in cols:
            if col in df.columns:
                df = df.drop(col, axis = 1)
        return df

    ############################################################################
    # 字符串清洗
    ############################################################################
    # 具体位置编码
    print('Encoding var23')
    train_test['var23'] = train_test['var23'].fillna(u'县')
    train_test.loc[train_test['var23'].apply(lambda x: x[-1] == u'省'), 'var23'] = u'县'
    train_test['var23_word'] = train_test['var23'].apply(lambda x: x[-1])
    train_test['var23_word'] = pd.factorize(train_test['var23_word'])[0]

    # var124/var125/var126
    train_test['var124'] = train_test['var124'].isnull().astype(int)
    train_test['var125'] = train_test['var125'].fillna('').apply(lambda x: len(x.split('@')))
    train_test['var126'] = train_test['var126'].fillna('').apply(lambda x: len(x.split('@')))

    ############################################################################
    # 城市编码
    ############################################################################
    city_rank = [
        u'''北京 上海 广州 深圳 天津''',
        u'''杭州 南京 济南 重庆 青岛 大连 宁波 厦门 成都 武汉 哈尔滨 沈阳 西安 长春 长沙 福州
        郑州 石家庄 苏州 佛山 东莞 无锡 烟台 太原 合肥 南昌 南宁 昆明 温州 淄博 唐山''',
        u'''乌鲁木齐 贵阳 海口 兰州 银川 西宁 呼和浩特 泉州 包头 南通 大庆 徐州 潍坊 常州 鄂尔多斯
        绍兴 济宁 盐城 邯郸 临沂 洛阳 东营 扬州 台州 嘉兴 沧州 榆林 泰州 镇江 昆山 江阴 张家港 义乌
        金华 保定 吉林 鞍山 泰安 宜昌 襄阳 中山 惠州 南阳 威海 德州 岳阳 聊城 常德 漳州 滨州 茂名
        淮安 江门 芜湖 湛江 廊坊 菏泽 柳州 宝鸡 珠海 绵阳''',
        u'''株洲 枣庄 许昌 通辽 湖州 新乡 咸阳 松原 连云港 安阳 周口 焦作 赤峰 邢台 郴州 宿迁 赣州
        平顶山 桂林 肇庆 曲靖 九江 商丘 汕头 信阳 驻马店 营口 揭阳 龙岩 安庆 日照 遵义 三明 呼伦贝尔
        长治 湘潭 德阳 南充 乐山 达州 盘锦 延安 上饶 锦州 宜春 宜宾 张家口 马鞍山 吕梁 抚顺 临汾 渭南
        开封 莆田 荆州 黄冈 四平 承德 齐齐哈尔 三门峡 秦皇岛 本溪 玉林 孝感 牡丹江 荆门 宁德 运城 绥化
        永州 怀化 黄石 泸州 清远 邵阳 衡水 益阳 丹东 铁岭 晋城 朔州 吉安 娄底 玉溪 辽阳 南平 濮阳 晋中
        资阳 都江堰 攀枝花 衢州 内江 滁州 阜阳 十堰 大同 朝阳 六安 宿州 通化 蚌埠 韶关 丽水 自贡 阳江 毕节''',
        u'''拉萨 克拉玛依 库尔勒 昌吉 哈密 伊宁 喀什 阿克苏 石河子 晋江 增城 诸暨 丹阳 玉环 常熟
        崇明 余姚 奉化 海宁 浏阳市 大理 丽江 普洱 保山 昭通 西昌 雅安 广安 广元 巴中 遂宁 天水
        酒泉 嘉峪关 武威 张掖 石嘴山 吴忠 北海 百色 虎门镇 长安镇 鳌江-龙港镇''',
    ]
    def find_index(li, ax):
        for i, x in enumerate(li):
            if ax in x:
                return i + 1
        return 6

    # 使用var21 填充 var25, 并对城市进行分级
    print('Encoding var25')
    train_test.loc[train_test['var25'].isnull(), 'var25'] = train_test.loc[train_test['var25'].isnull(), 'var21']
    train_test['var25'] = train_test['var25'].apply(lambda x: x.replace(u'市', ''))
    train_test['var25'] = train_test['var25'].apply(lambda x: find_index(city_rank, x))

    # 城市经纬度
    city_latiude_df = city_latiude(train_test)
    train_test['var21_cityx'] = city_latiude_df['var21_cityx']; train_test['var21_cityx'] = city_latiude_df['var21_cityy']

    ############################################################################
    # 构建二元交叉特征
    ############################################################################
    colcol2 = '''var30/var50 var26/var113 var2+var3 var1/var14 var54/var98 var26/var133
    var113/var114 var1-var14 var28/var48 var26*var36 var92/var98 var127/var128 var113/var125
    var113/var126 var1+var14 var30/var56 var2-var3 var26*var27 var286/var369 var29/var49
    var128/var131 var2*var3 var28/var107 var28/var99 var12/var16 var55/var128 var26/var132
    var209/var448 var36/var37 var156/var369 var369/var448 var209/var286 var97/var100 var6*var11
    var6+var11 var50/var56 var28/var108 var3-var4 var37/var40 var6/var12 var43/var82 var250/var256
    var28/var54 var26/var129 var91/var94 var120-var128 var55/var93 var160/var326 var89/var95
    var36*var129 var172-var395 var12*var100 var353/var433 var160/var428 var12*var16 var30/var99
    var12*var97 var37/var41 var6-var12 var209/var428 var209/var266 var6-var11 var121-var128
    var128/var130 var98/var107 var156-var209 var113/var129 var54/var107 var27/var36 var156/var209
    var36/var40 var38/var39 var7-var9 var38/var40 var369/var428 var166/var209 var103*var125
    var85/var88 var59/var101 var59/var102 var43-var82 var94/var97 var113/var132 var55/var109
    var30/var55 var12+var97 var6*var12 var128*var131 var29/var57 var39/var113 var37/var39
    var48/var107 var54/var92 var1*var14 var6/var11 var55/var104 var54/var108 var48/var54 var51/var92 var37/var91
    var56/var30 var33/var53 var92/var98 var57/var29 var28/var54 var85/var87 var89/var95
    var26*var36 var26*var127 var83/var84 var128/var131 var103*var104 var103/var104
    var127/var128 var26*var27 var109*var103 var46/var128 var48/var98 var109/var103
    '''
    colcol2 = re.split('\n| ', colcol2)
    colcol2 = [x for x in colcol2 if len(x) > 1]

    for col in colcol2:
        col1, col2 = re.split('\*|\+|-|/', col)
        if col.split('var')[1][-1] == '+':
            train_test[col1 + '+' + col2] = train_test[col1] + train_test[col2]
        elif col.split('var')[1][-1] == '-':
            train_test[col1 + '-' + col2] = train_test[col1] - train_test[col2]
        elif col.split('var')[1][-1] == '*':
            train_test[col1 + '*' + col2] = train_test[col1] * train_test[col2]
        elif col.split('var')[1][-1] == '/':
            train_test[col1 + '/' + col2] = train_test[col1] / (train_test[col2] + 0.01)

    ############################################################################
    # 类别特征，违约率排名
    ############################################################################
    # 类别违约排名
    def cat_rank(train_test, train_set, col):
        df_rank = train_set.groupby(col)['target'].mean().reset_index()
        df_rank[col + '_rank'] = df_rank['target'].rank()
        df_rank.drop('target', axis = 1, inplace=True)
        train_test = pd.merge(train_test, df_rank, on = col, how ='left')
        return train_test

    train_test = cat_rank(train_test, train_set, 'var3')
    train_test = cat_rank(train_test, train_set, 'var11')
    train_test = cat_rank(train_test, train_set, 'var19')
    train_test = cat_rank(train_test, train_set, 'var24')

    train_test = cat_rank(train_test, train_set, 'var2')
    train_test = cat_rank(train_test, train_set, 'var5')
    train_test = cat_rank(train_test, train_set, 'var25')
    train_test = cat_rank(train_test, train_set, 'var7')
    train_test = cat_rank(train_test, train_set, 'var8')
    train_test = cat_rank(train_test, train_set, 'var9')
    train_test = cat_rank(train_test, train_set, 'var13')
    train_test = cat_rank(train_test, train_set, 'var16')
    train_test = cat_rank(train_test, train_set, 'var103')
    train_test = cat_rank(train_test, train_set, 'var112')

    # 剔除字符串特征
    string_col = train_test.columns[train_test.dtypes == 'object']
    train_test = del_col(train_test, string_col)
    print('ALL DATA', train_test.shape)

    # 类别特征onehot编码
    cat_col = ['var3', 'var11', 'var16', 'var17', 'var18', 'var19', 'var23_word', 'var488']
    train_test = pd.get_dummies(train_test, columns=cat_col, prefix=cat_col)

    return train_test

################################################################################
# 数据输入
################################################################################
print("Reading data".center (70, '-'))
train_set, test_set, train_test = read_input()
print('Train {0}, Test {1}, ALL DATA {2}'.format(train_set.shape, test_set.shape, train_test.shape))

################################################################################
# 预处理
################################################################################
print("Prepocess".center (70, '-'))
train_test = preprocess(train_test)

################################################################################
# 特征工程
################################################################################
print("Feature".center (70, '-'))
train_test = feature(train_test)
print('ALL DATA', train_test.shape)

################################################################################
# 模型预测
################################################################################
print("Model".center (70, '-'))
n_fold = 5
kf = StratifiedKFold(n_splits = n_fold, shuffle = True)
eval_fun = roc_auc_score

def run_oof(clf, X_train, y_train, X_test, kf):
    print(clf.get_name())
    preds_train = np.zeros((len(X_train)), dtype = np.float)
    preds_test = np.zeros((len(X_test)), dtype = np.float)
    train_loss = []; test_loss = []

    i = 1
    for train_index, test_index in kf.split(X_train, y_train):
        x_tr = X_train[train_index]; x_te = X_train[test_index]
        y_tr = y_train[train_index]; y_te = y_train[test_index]

        if clf.get_name() in ['lightGBM', 'XGBoost']:
            clf.fit(x_tr, y_tr, x_te, y_te)

            train_loss.append(eval_fun(y_tr, clf.predict(x_tr)))
            test_loss.append(eval_fun(y_te, clf.predict(x_te)))

            preds_train[test_index] = clf.predict(x_te)
            preds_test += clf.predict(X_test)
        else:
            clf.fit(x_tr, y_tr)

            train_loss.append(eval_fun(y_tr, clf.predict(x_tr)))
            test_loss.append(eval_fun(y_te, clf.predict(x_te)))

            preds_train[test_index] = clf.predict(x_te)
            preds_test += clf.predict(X_test)

        print('{0}: Train {1:0.7f} Val {2:0.7f}/{3:0.7f}'.format(i, train_loss[-1], test_loss[-1], np.mean(test_loss)))
        print('-' * 50)
        i += 1
    print('Train: ', train_loss)
    print('Val: ', test_loss)
    print('-' * 50)
    print('{0} Train{1:0.5f}_Test{2:0.5f}\n\n'.format(clf.get_name(), np.mean(train_loss), np.mean(test_loss)))
    preds_test /= n_fold
    return preds_train, preds_test

xgb_params1 = {
    'eta' : 0.01,
    'min_child_weight': 15,
    'max_delta_step': 2,
    'colsample_bytree' : 0.75,
    'subsample' : 0.75,
    'seed' : 234,
    'max_depth' : 8,
    'nthread' : 6,
    'objective' : 'binary:logistic',
    'eval_metric' : 'auc',
    # 'num_class' : 2,
    'silent' : 1,
    # 'scale_pos_weight': 4.6796,
}

train_df = train_test.iloc[: train_set.shape[0], :]
test_df = train_test.iloc[train_set.shape[0]:, :]

train_df = np.array(train_df)
train_label = np.array(train_set['target'])
test_df = np.array(test_df)
n_classes = 2

xgb_clf = XgbWrapper(params = xgb_params1)
xgb_train, xgb_test = run_oof(xgb_clf, train_df, train_label, test_df, kf)

xgb_submit = pd.DataFrame()
xgb_submit['id'] = test_set.id
xgb_submit['predict'] = xgb_test
xgb_submit.to_csv('./1011.csv', index = None)
